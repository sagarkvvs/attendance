# SVLNS College Attendance System

## Overview

This is a modern student attendance management system built for SVLNS College. The application provides a comprehensive solution for tracking student attendance, managing academic years, and generating reports. It features a clean, intuitive interface built with React and shadcn/ui components, backed by a robust Express.js server with PostgreSQL database.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom SVLNS theme variables
- **State Management**: TanStack Query (React Query) for server state
- **Forms**: React Hook Form with Zod validation
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **API**: RESTful API design with structured endpoints
- **Validation**: Zod schemas for request/response validation
- **Development**: Hot reload with Vite integration

### Database Design
The system uses a relational database with the following key entities:
- **Academic Years**: Manages different academic periods with active/inactive states
- **Courses**: Stores course information (BSC Physics, etc.)
- **Students**: Student records linked to courses and academic years
- **Attendance**: Daily attendance records with status tracking
- **Users**: Faculty and admin authentication (basic structure)

## Key Components

### Pages
- **Dashboard**: Overview with attendance statistics and active academic year info
- **Students**: Student management with CRUD operations and filtering
- **Attendance**: Daily attendance marking with real-time stats
- **Years**: Academic year management with activation controls
- **Reports**: Attendance report generation with customizable filters

### Shared Components
- **Layout**: Responsive sidebar navigation with modern design
- **Header**: Consistent page headers with action buttons
- **UI Components**: Comprehensive set of reusable components from shadcn/ui

### Storage Layer
- **Abstract Interface**: IStorage interface defines all database operations
- **Type Safety**: Full TypeScript coverage with Drizzle-generated types
- **Query Optimization**: Efficient queries with proper joins and filtering

## Data Flow

1. **Client Requests**: React components make API calls using TanStack Query
2. **API Layer**: Express routes handle validation and business logic
3. **Storage Layer**: Abstract storage interface provides data access
4. **Database**: PostgreSQL stores and retrieves data via Drizzle ORM
5. **Response**: Structured JSON responses with proper error handling

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **react-hook-form**: Form handling with validation
- **@hookform/resolvers**: Zod integration for forms
- **wouter**: Lightweight React router

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives
- **tailwindcss**: Utility-first CSS framework
- **lucide-react**: Modern icon library
- **date-fns**: Date manipulation utilities

### Development Dependencies
- **tsx**: TypeScript execution for development
- **esbuild**: Fast bundling for production
- **vite**: Development server and build tool

## Deployment Strategy

### Development Environment
- **Platform**: Replit with Node.js 20 runtime
- **Database**: PostgreSQL 16 module
- **Port Configuration**: Internal port 5000, external port 80
- **Hot Reload**: Vite development server with HMR

### Production Build
- **Build Process**: Vite builds frontend, esbuild bundles backend
- **Output**: Static assets in `dist/public`, server bundle in `dist/index.js`
- **Environment**: Production mode with optimized assets
- **Deployment**: Autoscale deployment target

### Configuration
- **Database**: Drizzle migrations in `./migrations` directory
- **Schema**: Centralized in `shared/schema.ts` for type safety
- **Environment**: DATABASE_URL required for database connection

## Recent Changes

✓ June 24, 2025 - Enhanced SVLNS Attendance System with:
  - Added Years tab for academic year management  
  - Implemented attendance validation (prevents duplicates, enforces student limits)
  - Fixed Student Management page navigation and functionality
  - Added PostgreSQL database with Drizzle ORM integration
  - Created database schema with relations for academic years, courses, students, attendance, and users
  - Implemented comprehensive database storage layer replacing in-memory storage
  - Added database seeding with sample data for immediate testing
  - Created comprehensive admin management system for courses, years, and users
  - Added secure login portal with role-based authentication
  - Implemented role-based navigation (admin, faculty, hod access levels)
  - Enhanced user management with full profiles and login credentials

## Architecture Updates

### Database Integration (June 24, 2025)
- **Database**: Migrated from in-memory storage to PostgreSQL with Neon serverless
- **ORM**: Implemented Drizzle ORM with type-safe queries and relations
- **Schema**: Created comprehensive relational schema with proper foreign keys
- **Storage Layer**: Built DatabaseStorage class implementing full IStorage interface
- **Data Seeding**: Automatic initialization with sample academic years, courses, students, and users

### Authentication & Authorization (June 24, 2025)
- **Login System**: Secure faculty authentication with username/password
- **Role-Based Access**: Admin, Faculty, and HOD roles with different permission levels
- **Session Management**: Client-side session storage with automatic login persistence
- **User Interface**: Professional login portal with demo account quick access
- **Navigation Control**: Role-specific menu items and feature access

## User Preferences

Preferred communication style: Simple, everyday language.