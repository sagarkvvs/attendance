import { pgTable, text, serial, integer, boolean, timestamp, date, decimal } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const academicYears = pgTable("academic_years", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(), // e.g., "2024-25"
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  description: text("description"),
  isActive: boolean("is_active").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(), // e.g., "BSC Physics"
  code: text("code").notNull().unique(), // e.g., "bsc-physics"
  description: text("description"),
});

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rollNumber: text("roll_number").notNull().unique(),
  courseId: integer("course_id").references(() => courses.id),
  yearOfStudy: text("year_of_study").notNull(), // e.g., "1st", "2nd", "3rd"
  academicYearId: integer("academic_year_id").references(() => academicYears.id),
  contact: text("contact"),
  isActive: boolean("is_active").default(true),
});

export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id").references(() => students.id),
  academicYearId: integer("academic_year_id").references(() => academicYears.id),
  courseId: integer("course_id").references(() => courses.id),
  date: date("date").notNull(),
  status: text("status").notNull(), // "present", "absent", "late"
  markedAt: timestamp("marked_at").defaultNow(),
  markedBy: text("marked_by"), // faculty identifier
});

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("faculty"), // "admin", "faculty", "hod"
  fullName: text("full_name").notNull(),
  email: text("email"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Insert schemas
export const insertAcademicYearSchema = createInsertSchema(academicYears).omit({
  id: true,
  createdAt: true,
});

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
});

export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
});

export const insertAttendanceSchema = createInsertSchema(attendance).omit({
  id: true,
  markedAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

// Types
export type AcademicYear = typeof academicYears.$inferSelect;
export type InsertAcademicYear = z.infer<typeof insertAcademicYearSchema>;

export type Course = typeof courses.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;

export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;

export type Attendance = typeof attendance.$inferSelect;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// Extended types for API responses
export type StudentWithDetails = Student & {
  course?: Course;
  academicYear?: AcademicYear;
  todayAttendance?: Attendance;
  attendanceRate?: number;
};

export type AttendanceWithDetails = Attendance & {
  student?: Student;
  course?: Course;
  academicYear?: AcademicYear;
};

export type AcademicYearWithStats = AcademicYear & {
  totalStudents?: number;
  avgAttendance?: number;
  totalClasses?: number;
};

// Relations
export const academicYearsRelations = relations(academicYears, ({ many }) => ({
  students: many(students),
  attendance: many(attendance),
}));

export const coursesRelations = relations(courses, ({ many }) => ({
  students: many(students),
  attendance: many(attendance),
}));

export const studentsRelations = relations(students, ({ one, many }) => ({
  course: one(courses, {
    fields: [students.courseId],
    references: [courses.id],
  }),
  academicYear: one(academicYears, {
    fields: [students.academicYearId],
    references: [academicYears.id],
  }),
  attendance: many(attendance),
}));

export const attendanceRelations = relations(attendance, ({ one }) => ({
  student: one(students, {
    fields: [attendance.studentId],
    references: [students.id],
  }),
  course: one(courses, {
    fields: [attendance.courseId],
    references: [courses.id],
  }),
  academicYear: one(academicYears, {
    fields: [attendance.academicYearId],
    references: [academicYears.id],
  }),
}));

export const usersRelations = relations(users, ({ many }) => ({
  // Add any user relations here if needed
}));
