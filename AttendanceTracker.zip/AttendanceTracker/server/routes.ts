import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertAcademicYearSchema, 
  insertCourseSchema, 
  insertStudentSchema, 
  insertAttendanceSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Academic Years routes
  app.get("/api/academic-years", async (req, res) => {
    try {
      const years = await storage.getAcademicYears();
      res.json(years);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch academic years" });
    }
  });

  app.get("/api/academic-years/active", async (req, res) => {
    try {
      const activeYear = await storage.getActiveAcademicYear();
      if (!activeYear) {
        return res.status(404).json({ message: "No active academic year found" });
      }
      res.json(activeYear);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch active academic year" });
    }
  });

  app.post("/api/academic-years", async (req, res) => {
    try {
      const validatedData = insertAcademicYearSchema.parse(req.body);
      
      // Validate date range
      if (new Date(validatedData.startDate) >= new Date(validatedData.endDate)) {
        return res.status(400).json({ message: "Start date must be before end date" });
      }

      const year = await storage.createAcademicYear(validatedData);
      res.status(201).json(year);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create academic year" });
    }
  });

  app.put("/api/academic-years/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertAcademicYearSchema.partial().parse(req.body);
      
      const updatedYear = await storage.updateAcademicYear(id, validatedData);
      if (!updatedYear) {
        return res.status(404).json({ message: "Academic year not found" });
      }
      
      res.json(updatedYear);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update academic year" });
    }
  });

  app.delete("/api/academic-years/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteAcademicYear(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Academic year not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete academic year" });
    }
  });

  app.post("/api/academic-years/:id/activate", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const activated = await storage.setActiveAcademicYear(id);
      
      if (!activated) {
        return res.status(404).json({ message: "Academic year not found" });
      }
      
      res.json({ message: "Academic year activated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to activate academic year" });
    }
  });

  // Courses routes
  app.get("/api/courses", async (req, res) => {
    try {
      const courses = await storage.getCourses();
      res.json(courses);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch courses" });
    }
  });

  app.post("/api/courses", async (req, res) => {
    try {
      const validatedData = insertCourseSchema.parse(req.body);
      const course = await storage.createCourse(validatedData);
      res.status(201).json(course);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create course" });
    }
  });

  // Students routes
  app.get("/api/students", async (req, res) => {
    try {
      const { courseId, academicYearId, yearOfStudy } = req.query;
      const filters: any = {};
      
      if (courseId) filters.courseId = parseInt(courseId as string);
      if (academicYearId) filters.academicYearId = parseInt(academicYearId as string);
      if (yearOfStudy) filters.yearOfStudy = yearOfStudy as string;
      
      const students = await storage.getStudents(filters);
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.post("/api/students", async (req, res) => {
    try {
      const validatedData = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(validatedData);
      res.status(201).json(student);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create student" });
    }
  });

  app.put("/api/students/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertStudentSchema.partial().parse(req.body);
      
      const updatedStudent = await storage.updateStudent(id, validatedData);
      if (!updatedStudent) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      res.json(updatedStudent);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update student" });
    }
  });

  app.delete("/api/students/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteStudent(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Student not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete student" });
    }
  });

  // Attendance routes
  app.get("/api/attendance", async (req, res) => {
    try {
      const { date, courseId, academicYearId, studentId } = req.query;
      const filters: any = {};
      
      if (date) filters.date = date as string;
      if (courseId) filters.courseId = parseInt(courseId as string);
      if (academicYearId) filters.academicYearId = parseInt(academicYearId as string);
      if (studentId) filters.studentId = parseInt(studentId as string);
      
      const attendance = await storage.getAttendance(filters);
      res.json(attendance);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch attendance" });
    }
  });

  app.post("/api/attendance", async (req, res) => {
    try {
      const validatedData = insertAttendanceSchema.parse(req.body);
      
      // Check for duplicate attendance (prevent marking twice)
      const exists = await storage.checkAttendanceExists(
        validatedData.studentId!, 
        validatedData.date
      );
      
      if (exists) {
        return res.status(400).json({ 
          message: "Attendance already marked for this student on this date" 
        });
      }
      
      // Validate present count doesn't exceed total students
      const students = await storage.getStudents({ 
        courseId: validatedData.courseId || undefined,
        academicYearId: validatedData.academicYearId || undefined
      });
      
      const todayAttendance = await storage.getAttendance({
        date: validatedData.date,
        courseId: validatedData.courseId || undefined,
        academicYearId: validatedData.academicYearId || undefined
      });
      
      const presentCount = todayAttendance.filter((a: any) => a.status === "present").length;
      if (validatedData.status === "present" && presentCount >= students.length) {
        return res.status(400).json({
          message: `Cannot mark present: all ${students.length} students already marked present`
        });
      }
      
      const attendance = await storage.markAttendance(validatedData);
      res.status(201).json(attendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to mark attendance" });
    }
  });

  app.post("/api/attendance/bulk", async (req, res) => {
    try {
      const { attendanceRecords } = req.body;
      
      if (!Array.isArray(attendanceRecords)) {
        return res.status(400).json({ message: "attendanceRecords must be an array" });
      }

      const results = [];
      const errors = [];

      for (const record of attendanceRecords) {
        try {
          const validatedData = insertAttendanceSchema.parse(record);
          
          // Check for duplicate attendance
          const exists = await storage.checkAttendanceExists(
            validatedData.studentId || 0, 
            validatedData.date
          );
          
          if (exists) {
            errors.push({
              studentId: validatedData.studentId,
              error: "Attendance already marked for this date"
            });
            continue;
          }
          
          const attendance = await storage.markAttendance(validatedData);
          results.push(attendance);
        } catch (error) {
          errors.push({
            studentId: record.studentId,
            error: error instanceof Error ? error.message : "Unknown error"
          });
        }
      }

      res.json({
        success: results.length,
        errors: errors.length,
        results,
        errorDetails: errors
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to process bulk attendance" });
    }
  });

  app.get("/api/attendance/stats", async (req, res) => {
    try {
      const { courseId, academicYearId, dateFrom, dateTo } = req.query;
      const filters: any = {};
      
      if (courseId) filters.courseId = parseInt(courseId as string);
      if (academicYearId) filters.academicYearId = parseInt(academicYearId as string);
      if (dateFrom) filters.dateFrom = dateFrom as string;
      if (dateTo) filters.dateTo = dateTo as string;
      
      const stats = await storage.getAttendanceStats(filters);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch attendance statistics" });
    }
  });

  // Validation routes
  app.post("/api/attendance/validate", async (req, res) => {
    try {
      const { studentIds, date, courseId } = req.body;
      
      if (!Array.isArray(studentIds)) {
        return res.status(400).json({ message: "studentIds must be an array" });
      }

      const validation: {
        duplicates: number[];
        errors: string[];
        valid: boolean;
      } = {
        duplicates: [],
        errors: [],
        valid: true
      };

      // Check for existing attendance
      for (const studentId of studentIds) {
        const exists = await storage.checkAttendanceExists(studentId, date);
        if (exists) {
          validation.duplicates.push(studentId);
          validation.valid = false;
        }
      }

      // Get course capacity validation
      const students = await storage.getStudents({ courseId });
      const presentCount = studentIds.filter((id: number) => 
        !validation.duplicates.includes(id)
      ).length;

      if (presentCount > students.length) {
        validation.errors.push(
          `Present count (${presentCount}) exceeds total enrolled students (${students.length})`
        );
        validation.valid = false;
      }

      res.json(validation);
    } catch (error) {
      res.status(500).json({ message: "Failed to validate attendance" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
