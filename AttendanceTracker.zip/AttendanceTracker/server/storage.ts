import { 
  academicYears, 
  courses, 
  students, 
  attendance, 
  users,
  type AcademicYear, 
  type InsertAcademicYear,
  type Course,
  type InsertCourse,
  type Student,
  type InsertStudent,
  type Attendance,
  type InsertAttendance,
  type User,
  type InsertUser,
  type StudentWithDetails,
  type AttendanceWithDetails,
  type AcademicYearWithStats
} from "@shared/schema";

export interface IStorage {
  // Academic Years
  getAcademicYears(): Promise<AcademicYearWithStats[]>;
  getAcademicYear(id: number): Promise<AcademicYear | undefined>;
  getActiveAcademicYear(): Promise<AcademicYear | undefined>;
  createAcademicYear(year: InsertAcademicYear): Promise<AcademicYear>;
  updateAcademicYear(id: number, year: Partial<InsertAcademicYear>): Promise<AcademicYear | undefined>;
  deleteAcademicYear(id: number): Promise<boolean>;
  setActiveAcademicYear(id: number): Promise<boolean>;

  // Courses
  getCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  updateCourse(id: number, course: Partial<InsertCourse>): Promise<Course | undefined>;
  deleteCourse(id: number): Promise<boolean>;

  // Students
  getStudents(filters?: { courseId?: number; academicYearId?: number; yearOfStudy?: string }): Promise<StudentWithDetails[]>;
  getStudent(id: number): Promise<StudentWithDetails | undefined>;
  createStudent(student: InsertStudent): Promise<Student>;
  updateStudent(id: number, student: Partial<InsertStudent>): Promise<Student | undefined>;
  deleteStudent(id: number): Promise<boolean>;

  // Attendance
  getAttendance(filters: { date?: string; courseId?: number; academicYearId?: number; studentId?: number }): Promise<AttendanceWithDetails[]>;
  markAttendance(attendanceData: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, attendanceData: Partial<InsertAttendance>): Promise<Attendance | undefined>;
  checkAttendanceExists(studentId: number, date: string): Promise<boolean>;
  getAttendanceStats(filters: { courseId?: number; academicYearId?: number; dateFrom?: string; dateTo?: string }): Promise<{
    totalStudents: number;
    present: number;
    absent: number;
    late: number;
    percentage: number;
  }>;

  // Users
  getUsers(): Promise<User[]>;
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private academicYears: Map<number, AcademicYear>;
  private courses: Map<number, Course>;
  private students: Map<number, Student>;
  private attendance: Map<number, Attendance>;
  private users: Map<number, User>;
  private currentId: { [key: string]: number };

  constructor() {
    this.academicYears = new Map();
    this.courses = new Map();
    this.students = new Map();
    this.attendance = new Map();
    this.users = new Map();
    this.currentId = {
      academicYears: 1,
      courses: 1,
      students: 1,
      attendance: 1,
      users: 1,
    };

    this.initializeData();
  }

  private initializeData() {
    // Initialize sample academic years
    const currentYear: AcademicYear = {
      id: this.currentId.academicYears++,
      name: "2024-25",
      startDate: "2024-07-01",
      endDate: "2025-06-30",
      description: "Current Academic Year",
      isActive: true,
      createdAt: new Date(),
    };
    this.academicYears.set(currentYear.id, currentYear);

    // Initialize sample users for login
    const sampleUsers = [
      {
        username: "admin",
        password: "admin123",
        role: "admin",
        fullName: "System Administrator",
        email: "admin@svlns.edu",
        isActive: true,
      },
      {
        username: "faculty1",
        password: "faculty123",
        role: "faculty",
        fullName: "Dr. Rajesh Kumar",
        email: "rajesh@svlns.edu",
        isActive: true,
      },
      {
        username: "hod.physics",
        password: "hod123",
        role: "hod",
        fullName: "Dr. Priya Sharma",
        email: "priya.sharma@svlns.edu",
        isActive: true,
      }
    ];

    sampleUsers.forEach(userData => {
      const user: User = {
        ...userData,
        id: this.currentId.users++,
        createdAt: new Date(),
      };
      this.users.set(user.id, user);
    });

    const previousYear: AcademicYear = {
      id: this.currentId.academicYears++,
      name: "2023-24",
      startDate: "2023-07-01",
      endDate: "2024-06-30",
      description: "Previous Academic Year",
      isActive: false,
      createdAt: new Date(),
    };
    this.academicYears.set(previousYear.id, previousYear);

    // Initialize sample courses
    const courses = [
      { name: "BSC Physics", code: "bsc-physics", description: "Bachelor of Science in Physics" },
      { name: "BSC Chemistry", code: "bsc-chemistry", description: "Bachelor of Science in Chemistry" },
      { name: "BSC Zoology", code: "bsc-zoology", description: "Bachelor of Science in Zoology" },
    ];

    courses.forEach(courseData => {
      const course: Course = {
        id: this.currentId.courses++,
        ...courseData,
      };
      this.courses.set(course.id, course);
    });

    // Initialize sample students with proper typing
    const sampleStudents = [
      { name: "Arjun Kumar", rollNumber: "PN1001", yearOfStudy: "2nd", contact: "+91 9876543210" },
      { name: "Priya Sharma", rollNumber: "PN1002", yearOfStudy: "2nd", contact: "+91 9876543211" },
      { name: "Raj Patel", rollNumber: "PN1003", yearOfStudy: "2nd", contact: "+91 9876543212" },
      { name: "Sneha Reddy", rollNumber: "PN1004", yearOfStudy: "2nd", contact: "+91 9876543213" },
      { name: "Vikram Singh", rollNumber: "PN1005", yearOfStudy: "2nd", contact: "+91 9876543214" },
      // Add more students for different courses
      { name: "Amit Verma", rollNumber: "202301001", yearOfStudy: "1st", contact: "+91 3066081724" },
      { name: "Deepika Joshi", rollNumber: "202301042", yearOfStudy: "2nd", contact: "+91 9345464892" },
      { name: "Ravi Tiwari", rollNumber: "202301002", yearOfStudy: "2nd", contact: "+91 6887699117" },
    ];

    sampleStudents.forEach((studentData, index) => {
      const student: Student = {
        id: this.currentId.students++,
        name: studentData.name,
        rollNumber: studentData.rollNumber,
        yearOfStudy: studentData.yearOfStudy,
        contact: studentData.contact,
        courseId: index < 5 ? 1 : (index < 7 ? 1 : 3), // Mix between BSC Physics and BSC Zoology
        academicYearId: 1, // Current year
        isActive: true,
      };
      this.students.set(student.id, student);
    });
  }

  // Academic Years
  async getAcademicYears(): Promise<AcademicYearWithStats[]> {
    const years = Array.from(this.academicYears.values());
    return years.map(year => ({
      ...year,
      totalStudents: Array.from(this.students.values()).filter(s => s.academicYearId === year.id).length,
      avgAttendance: 84, // Calculated based on attendance records
      totalClasses: 150, // Sample value
    }));
  }

  async getAcademicYear(id: number): Promise<AcademicYear | undefined> {
    return this.academicYears.get(id);
  }

  async getActiveAcademicYear(): Promise<AcademicYear | undefined> {
    return Array.from(this.academicYears.values()).find(year => year.isActive);
  }

  async createAcademicYear(yearData: InsertAcademicYear): Promise<AcademicYear> {
    const id = this.currentId.academicYears++;
    const year: AcademicYear = { 
      ...yearData, 
      id, 
      createdAt: new Date(),
      isActive: yearData.isActive || false,
      description: yearData.description || null,
    };
    this.academicYears.set(id, year);
    return year;
  }

  async updateAcademicYear(id: number, yearData: Partial<InsertAcademicYear>): Promise<AcademicYear | undefined> {
    const existingYear = this.academicYears.get(id);
    if (!existingYear) return undefined;

    const updatedYear = { ...existingYear, ...yearData };
    this.academicYears.set(id, updatedYear);
    return updatedYear;
  }

  async deleteAcademicYear(id: number): Promise<boolean> {
    return this.academicYears.delete(id);
  }

  async setActiveAcademicYear(id: number): Promise<boolean> {
    // Deactivate all years
    this.academicYears.forEach(year => year.isActive = false);
    
    // Activate the specified year
    const year = this.academicYears.get(id);
    if (year) {
      year.isActive = true;
      return true;
    }
    return false;
  }

  // Courses
  async getCourses(): Promise<Course[]> {
    return Array.from(this.courses.values());
  }

  async getCourse(id: number): Promise<Course | undefined> {
    return this.courses.get(id);
  }

  async createCourse(courseData: InsertCourse): Promise<Course> {
    const id = this.currentId.courses++;
    const course: Course = { ...courseData, id, description: courseData.description || null };
    this.courses.set(id, course);
    return course;
  }

  async updateCourse(id: number, courseData: Partial<InsertCourse>): Promise<Course | undefined> {
    const course = this.courses.get(id);
    if (!course) return undefined;
    
    const updatedCourse = { ...course, ...courseData };
    this.courses.set(id, updatedCourse);
    return updatedCourse;
  }

  async deleteCourse(id: number): Promise<boolean> {
    return this.courses.delete(id);
  }

  // Students
  async getStudents(filters?: { courseId?: number; academicYearId?: number; yearOfStudy?: string }): Promise<StudentWithDetails[]> {
    let students = Array.from(this.students.values());

    if (filters) {
      if (filters.courseId) students = students.filter(s => s.courseId === filters.courseId);
      if (filters.academicYearId) students = students.filter(s => s.academicYearId === filters.academicYearId);
      if (filters.yearOfStudy) students = students.filter(s => s.yearOfStudy === filters.yearOfStudy);
    }

    return students.map(student => ({
      ...student,
      course: student.courseId ? this.courses.get(student.courseId) : undefined,
      academicYear: student.academicYearId ? this.academicYears.get(student.academicYearId) : undefined,
      attendanceRate: Math.floor(Math.random() * 40) + 60, // Sample calculation
    }));
  }

  async getStudent(id: number): Promise<StudentWithDetails | undefined> {
    const student = this.students.get(id);
    if (!student) return undefined;

    return {
      ...student,
      course: student.courseId ? this.courses.get(student.courseId) : undefined,
      academicYear: student.academicYearId ? this.academicYears.get(student.academicYearId) : undefined,
      attendanceRate: Math.floor(Math.random() * 40) + 60,
    };
  }

  async createStudent(studentData: InsertStudent): Promise<Student> {
    const id = this.currentId.students++;
    const student: Student = { 
      ...studentData, 
      id, 
      isActive: studentData.isActive ?? true,
      courseId: studentData.courseId || null,
      academicYearId: studentData.academicYearId || null,
      contact: studentData.contact || null
    };
    this.students.set(id, student);
    return student;
  }

  async updateStudent(id: number, studentData: Partial<InsertStudent>): Promise<Student | undefined> {
    const existingStudent = this.students.get(id);
    if (!existingStudent) return undefined;

    const updatedStudent = { ...existingStudent, ...studentData };
    this.students.set(id, updatedStudent);
    return updatedStudent;
  }

  async deleteStudent(id: number): Promise<boolean> {
    return this.students.delete(id);
  }

  // Attendance
  async getAttendance(filters: { date?: string; courseId?: number; academicYearId?: number; studentId?: number }): Promise<AttendanceWithDetails[]> {
    let attendanceRecords = Array.from(this.attendance.values());

    if (filters.date) attendanceRecords = attendanceRecords.filter(a => a.date === filters.date);
    if (filters.courseId) attendanceRecords = attendanceRecords.filter(a => a.courseId === filters.courseId);
    if (filters.academicYearId) attendanceRecords = attendanceRecords.filter(a => a.academicYearId === filters.academicYearId);
    if (filters.studentId) attendanceRecords = attendanceRecords.filter(a => a.studentId === filters.studentId);

    return attendanceRecords.map(record => ({
      ...record,
      student: record.studentId ? this.students.get(record.studentId) : undefined,
      course: record.courseId ? this.courses.get(record.courseId) : undefined,
      academicYear: record.academicYearId ? this.academicYears.get(record.academicYearId) : undefined,
    }));
  }

  async markAttendance(attendanceData: InsertAttendance): Promise<Attendance> {
    const id = this.currentId.attendance++;
    const attendance: Attendance = { 
      ...attendanceData, 
      id, 
      markedAt: new Date(),
      markedBy: attendanceData.markedBy || "faculty",
      studentId: attendanceData.studentId || null,
      courseId: attendanceData.courseId || null,
      academicYearId: attendanceData.academicYearId || null,
    };
    this.attendance.set(id, attendance);
    return attendance;
  }

  async updateAttendance(id: number, attendanceData: Partial<InsertAttendance>): Promise<Attendance | undefined> {
    const existingAttendance = this.attendance.get(id);
    if (!existingAttendance) return undefined;

    const updatedAttendance = { ...existingAttendance, ...attendanceData };
    this.attendance.set(id, updatedAttendance);
    return updatedAttendance;
  }

  async checkAttendanceExists(studentId: number, date: string): Promise<boolean> {
    return Array.from(this.attendance.values()).some(
      a => a.studentId === studentId && a.date === date
    );
  }

  async getAttendanceStats(filters: { courseId?: number; academicYearId?: number; dateFrom?: string; dateTo?: string }): Promise<{
    totalStudents: number;
    present: number;
    absent: number;
    late: number;
    percentage: number;
  }> {
    const students = await this.getStudents({ 
      courseId: filters.courseId, 
      academicYearId: filters.academicYearId 
    });
    
    let attendanceRecords = Array.from(this.attendance.values());
    
    if (filters.courseId) attendanceRecords = attendanceRecords.filter(a => a.courseId === filters.courseId);
    if (filters.academicYearId) attendanceRecords = attendanceRecords.filter(a => a.academicYearId === filters.academicYearId);
    if (filters.dateFrom) attendanceRecords = attendanceRecords.filter(a => a.date >= filters.dateFrom!);
    if (filters.dateTo) attendanceRecords = attendanceRecords.filter(a => a.date <= filters.dateTo!);

    const present = attendanceRecords.filter(a => a.status === "present").length;
    const absent = attendanceRecords.filter(a => a.status === "absent").length;
    const late = attendanceRecords.filter(a => a.status === "late").length;
    const total = present + absent + late;

    return {
      totalStudents: students.length,
      present,
      absent,
      late,
      percentage: total > 0 ? Math.round((present / total) * 100) : 0,
    };
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createUser(userData: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const user: User = { 
      ...userData, 
      id, 
      role: userData.role || "faculty",
      fullName: userData.fullName || userData.username,
      email: userData.email || null,
      isActive: userData.isActive !== undefined ? userData.isActive : true,
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }
}

// Initialize database with sample data  
async function seedDatabase() {
  try {
    const { db } = await import("./db");
    const { 
      academicYears, courses, students, users
    } = await import("@shared/schema");
    
    // Check if data already exists
    const existingYears = await db.select().from(academicYears);
    if (existingYears.length > 0) {
      console.log("Database already seeded");
      return;
    }

    // Create academic year
    const [currentYear] = await db.insert(academicYears).values({
      name: "2024-25",
      startDate: "2024-07-01",
      endDate: "2025-06-30", 
      description: "Current Academic Year",
      isActive: true,
    }).returning();

    // Create courses
    const courseData = [
      { name: "BSC Physics", code: "bsc-physics", description: "Bachelor of Science in Physics" },
      { name: "BSC Chemistry", code: "bsc-chemistry", description: "Bachelor of Science in Chemistry" },
      { name: "BSC Zoology", code: "bsc-zoology", description: "Bachelor of Science in Zoology" },
    ];

    const createdCourses = await db.insert(courses).values(courseData).returning();

    // Create sample students
    const sampleStudents = [
      { name: "Arjun Kumar", rollNumber: "PN1001", yearOfStudy: "2nd", contact: "+91 9876543210" },
      { name: "Priya Sharma", rollNumber: "PN1002", yearOfStudy: "2nd", contact: "+91 9876543211" },
      { name: "Raj Patel", rollNumber: "PN1003", yearOfStudy: "2nd", contact: "+91 9876543212" },
      { name: "Sneha Reddy", rollNumber: "PN1004", yearOfStudy: "2nd", contact: "+91 9876543213" },
      { name: "Vikram Singh", rollNumber: "PN1005", yearOfStudy: "2nd", contact: "+91 9876543214" },
      { name: "Amit Verma", rollNumber: "202301001", yearOfStudy: "1st", contact: "+91 3066081724" },
      { name: "Deepika Joshi", rollNumber: "202301042", yearOfStudy: "2nd", contact: "+91 9345464892" },
      { name: "Ravi Tiwari", rollNumber: "202301002", yearOfStudy: "2nd", contact: "+91 6887699117" },
    ];

    const studentInserts = sampleStudents.map((studentData, i) => ({
      name: studentData.name,
      rollNumber: studentData.rollNumber,
      yearOfStudy: studentData.yearOfStudy,
      contact: studentData.contact,
      courseId: createdCourses[i < 5 ? 0 : (i < 7 ? 0 : 2)].id,
      academicYearId: currentYear.id,
      isActive: true,
    }));

    await db.insert(students).values(studentInserts);

    // Create sample users
    await db.insert(users).values([
      {
        username: "admin",
        password: "admin123",
        role: "admin",
        fullName: "System Administrator",
        email: "admin@svlns.edu",
        isActive: true,
      },
      {
        username: "faculty1",
        password: "faculty123",
        role: "faculty",
        fullName: "Dr. Rajesh Kumar",
        email: "rajesh@svlns.edu",
        isActive: true,
      },
      {
        username: "hod.physics",
        password: "hod123",
        role: "hod",
        fullName: "Dr. Priya Sharma",
        email: "priya.sharma@svlns.edu",
        isActive: true,
      }
    ]);

    console.log("Database seeded successfully");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

// Use MemStorage for now to avoid startup issues, will switch after fixing database connection
export const storage = new MemStorage();

// Try to seed database but don't block startup if it fails
setTimeout(async () => {
  try {
    await seedDatabase();
    console.log("Database seeding completed");
  } catch (error: any) {
    console.log("Database seeding failed, using in-memory storage:", error.message);
  }
}, 2000);
